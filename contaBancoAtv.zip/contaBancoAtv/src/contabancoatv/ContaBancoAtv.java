/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package contabancoatv;

/**
 *
 * @author rafael
 */
public class ContaBancoAtv {
    //atributos da classe
    public int numConta;
    protected String tipo;
    private String dono;
    private double saldo;
    private boolean status;
    //metodos da classe
    public ContaBancoAtv(){
        status=false;
        numConta=0;
    }
    public int abrirConta(String m){
       status = true;
       tipo=m;
       if(tipo.equals("cp")&&tipo.equals("cc")){
           if(tipo.equals("cp")){
               numConta = 150;
           }
           if(tipo.equals("cc")){
               numConta=150;
          }
       }else{
           return 0; 
       }
       return numConta;
    }
    public int fecharConta(){
        if(numConta==0){
            status=false;
        }
        return 0;
    }
    public int depositar(int deposito){
        if(status==true){
            numConta+=deposito;
        }
        return numConta;
    }
    public int sacar(int saque){
        if(status==true&& numConta>0){
            numConta-=saque;
        }
        return numConta;
    }
    public int pagarMensal(boolean saldo){
        if(saldo==true){
            if(tipo.equals("cc")){
                numConta-=12;
            }
            if(tipo.equals("cp")){
                numConta-=20;
            }
        }
        return numConta;
    }
    //getters and setters
    public int getNumConta() {
        return numConta;
    }

    public void setNumConta(int numConta) {
        this.numConta = numConta;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getDono() {
        return dono;
    }

    public void setDono(String dono) {
        this.dono = dono;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }
}