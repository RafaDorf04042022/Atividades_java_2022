/*
Atividade JOptionPane.
Se deve criar uma caixa de mensagem que pede um valor para o usuario e retorna as informações sobre a quantidade de numeros,
quantidade desses numeros que são pares, que são impares, seus valores acima de 100 e a média de todos eles.
*/
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ofcpackage;
//Bibliotecas importadas
import java.util.Arrays;
import javax.swing.JOptionPane;

/**
 *
 * @author rafael
 */
//Classe principal
public class JoptionAtividadeOfc {
    //main, onde vai ser executado o código.
    public static void main(String[] arghs){
        //variável que receberá os valores que o usuário digitar em tipo inteiro
        int controlValue=1;
        //variável que fará controle do local dentro do array que receberá os valores que forem escritos na variável anterior
        int controlArray=1;
        //Array oficial que receberá todos os valores digitados pelo usuário, incluindo o "0" que interrompe o código
        int[] arrayOfc= new int[0];
        //repetição principal
        while(controlValue!=0){
            //variável de tipo string que recebe os valores digitados pelo usuário em um JOptionPane
            String receiveValue = JOptionPane.showInputDialog(null, "Informe um valor \n"+"0 interrompe", JOptionPane.INFORMATION_MESSAGE);
            //Valor recebido convertido para inteiro
            controlValue=Integer.parseInt(receiveValue);
            //segundo array criado com 1 espaço extra dentro e o conteudo do array principal copiado para os espaços anteriores
            int[] arrayTest = Arrays.copyOf(arrayOfc, arrayOfc.length+1);
            //array oficial recebe o outro array com espaço extra criado
            arrayOfc=arrayTest;
            //no espaço alocado pelo usuario vai ser recebido o valor que ele escreveu, dentro do array
            arrayOfc [controlArray-1] = controlValue;
            //aqui é incrementado um valor pra proxima repetição
            controlArray=controlArray+1;            
        }
        //variável que recebe incrementa para os pares
        int numerosPares=0;
        int controlValueGeral=0;
        //variável que incrementa para os impares
        int numerosImpares=0;
        //repetição para os pares e impares
        while (controlValueGeral!=(controlArray-1)){
            //caso em que é par
            if (arrayOfc[controlValueGeral] % 2 == 0){
                numerosPares++;
            }
            //caso em que é impar
            else{
                numerosImpares++;
            }
            controlValueGeral++;
        }
       controlValueGeral=0;
       int controlTest=0;
       //repetições para absorver maiores que 100
       while (controlValueGeral!=(controlArray-1)){
            if (arrayOfc[controlValueGeral]>100){
                controlTest++;
            }
            controlValueGeral++;
        }
       controlValueGeral=0;
       int somaValue=0;
       //repetição que recebe a soma de todos os valores
       while (controlValueGeral!=(controlArray-1)){
            somaValue=arrayOfc[controlValueGeral]+somaValue;
            controlValueGeral++;
        }
       //variável que recebe as médias
       int mediaValue=somaValue/(controlValueGeral-1);
       //cria um Pane com todas as informações requisitadas
       JOptionPane.showMessageDialog(null,"Resultado:\n"+"Total de valores:"+ (controlArray-2)+"\n"+"Total de pares:"+(numerosPares-1)+"\n"+"Total de impares"+(numerosImpares)+"\n"+"Valores acima de 100:"+(controlTest)+"\n"+"Média dos valores:"+(mediaValue));
    }
}