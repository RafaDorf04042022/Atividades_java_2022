//Atividade do gênio
//Rafael Ferreira Machado
/*obs: o objetivo dessa aplicação é que o jogador tente adivinhar qual é o numero que o "gênio", ou melhor,
 a class Random vai gerar. Caso ele acerte, receberá uma mensagem de bonificação, caso não, será julgado.
  NO geral, ele vai colocar um valor que ele achar adequado no Jspinner, que receberá o valor. Foi determinado
  um range de 1 até 5, mas ele pode colocar numeros diferentes, só que obviamente ele vai perder nesse caso. Quando
  ele apertar no Jbuttom que porcessará o codigo em actionPerfomed e vai comparar os valores recebidos pelo usuário
  e pela variável randômica. Caso seja igual, o condicional "if" vai encaminhar para um código que modifica o Jlabel
  onde está escrito a frase de apresentação e vai adicionar a frase de bonificação. Caso não seja igual, o condicional
  "else" vai fazer o mesmo só que com uma frase de julgamento por ter perdido o jogo.*/
package packageGenius;
//Bibliotecas usadas, tanto as bibliotecas de interface e da ação do Jbutton quanto a biblioteca do numero randômico.
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
//Classe principal
public class geniusGame {
    //foi criado os elementos da interface
    private JPanel pnlOfc;
    private JButton btnPalpite;
    private JSpinner spnPalpiteValue;
    private JLabel lblRedEye;
    private JLabel lblGuilhotina;
    private JLabel lblReceiveValue;
    //onde vai ser executado o código principal, dentro das funcionalidades que necessitam do Jbutton em actionPerfomed
    public geniusGame() {
        btnPalpite.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                //variável que recebe o Jspinner como inteiro
                int varValueOfc= (int) spnPalpiteValue.getValue();
                //classe Random que sendo usada em uma variável que gerará o numero randômico
                Random varRandom= new Random();
                //variável que recebe o número randômico como inteiro e selecionando apenas o range de 1 até 5
                int receiveRandom=varRandom.nextInt(5)+1;
                //condicional que compara o valor do Jspinner e do número randômico e condiciona pro caso de uma igualdade
                if (varValueOfc==receiveRandom){
                    //mensagem de bonificação
                    lblReceiveValue.setText("Parabéns, você não morrerá amanhã");
                }
                //condicional para o caso da condicional anterior está errada
                else {
                    //mensagem de julgamento
                    lblReceiveValue.setText("É o seu fim meu caro");
                };
            }
        });
    }
    //Execução da interface
    public static void main(String[] args) {
        JFrame frame = new JFrame("Não jogue isso!!!!");
        frame.setContentPane(new geniusGame().pnlOfc);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
